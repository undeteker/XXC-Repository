# XXC-Repository
## MAY TAKE 1 - 3 MINUTES TO LOAD (needs to download b4 injecting) estimated 2 minutes to fully download on standard pc 
XXC Executor, original file was taken down. I reuploaded with uploaders permission.

NOTE: OWNER IS LINKED TO A KNOWN DATA LEAK IN 2021 DUE TO SECURITY REASONS REVOLVING AROUND THEIR DATA BASE, USE AT YOUR OWN RISK. THIS IS AN ARCHIVE OF AN UPDATED EXECUTOR CODED IN PY, YOUR SAFETY IS NOT GUARANTEED. 
